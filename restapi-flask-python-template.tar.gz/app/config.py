# pylint: disable=R0903
"""
Global config
"""


class Config:
    """ config """
    ADMIN_KEY = '3621b540-b0f2-48b5-bf4b-1645b17110ce'
